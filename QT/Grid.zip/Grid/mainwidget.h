#ifndef MAINWIDGET_H
#define MAINWIDGET_H

#include <QMainWindow>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QLabel>
#include <string>

class MainWidget : public QWidget
{
    Q_OBJECT

public:
    MainWidget(QMainWindow *parent = nullptr): QWidget(parent)
    {
        //
        layout = new QGridLayout();
        edit = new QLineEdit();
        button = new QPushButton("Click");
        label = new QLabel();

        //
        layout->addWidget(edit, 0,0);
        layout->addWidget(button,1,0);
        layout->addWidget(label,2,0);

        setLayout(layout);
        connect(button, SIGNAL(clicked()), this, SLOT(changeText()));
    }

    ~MainWidget()
    {
        delete edit;
        delete button;
        delete label;
        delete layout;
    }

private slots:
    void changeText()
    {
        label->setText(edit->text());
    }

private:
    QLineEdit *edit;
    QPushButton *button;
    QLabel *label;
    QGridLayout *layout;
    std::string text;
};

#endif // MAINWIDGET_H
